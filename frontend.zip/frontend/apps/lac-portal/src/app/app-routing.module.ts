import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ImpressumComponent } from '@lac/ui-navigation';
import { AuthGuard } from '@lac/apis';

const routes: Routes = [
  { path: '', loadChildren: () => import('@lac/feature-discovery').then(m => m.FeatureDiscoveryModule)},
  { path: 'deposit', loadChildren: () => import('@lac/feature-deposit').then(m => m.FeatureDepositModule), canActivate: [AuthGuard] },
  { path: 'elan-player', loadChildren: () => import('@lac/feature-elan-player').then(m => m.FeatureElanPlayerModule), canActivate: [AuthGuard] },
  { path: 'docs', loadChildren: () => import('@lac/feature-docs').then(m => m.FeatureDocsModule) },
  { path: 'impressum', component: ImpressumComponent},
  { path: '**', redirectTo: '', pathMatch: 'full' },
]; 

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    scrollOffset: [0, 0],
    onSameUrlNavigation: 'reload'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
