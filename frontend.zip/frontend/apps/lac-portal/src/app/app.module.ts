import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UrlSerializer } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { CustomUrlSerializer, AuthInterceptor } from '@lac/apis';
import { APP_ENVIRONMENTS_CONFIG } from '@lac/config';
import { UiNavigationModule } from '@lac/ui-navigation';
import { environment } from '../environments/environment';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    UiNavigationModule,
    HttpClientModule,
    FontAwesomeModule
  ],
  providers: [
    { provide: APP_ENVIRONMENTS_CONFIG, useValue: {
      a5BASE_URL: environment.api,
      a5QUERY: `${environment.api}${environment.queryApi}${environment.repository}`,
      a5OBJECT: `${environment.api}${environment.objectApi}${environment.repository}`,
      a5MEDIA: `${environment.api}${environment.mediApi}${environment.repository}`,
      a5ANNOTATION: `${environment.api}${environment.annotationApi}${environment.repository}`,
      a5DEPOSIT: `${environment.api}${environment.depositApi}${environment.repository}`,
      a5DOWNLOAD:  `${environment.downloadApi}`,
      a5AUTH_LOGIN: `${environment.api}${environment.authLogin}`,
      a5AUTH_VALIDATE: `${environment.api}${environment.authValidate}`,
      a5AUTH_FRONTEND: `${environment.authFrontend}`,
      a5AUTH_FRONTEND_LOGIN: `${environment.authFrontendLogin}`,
      a5AUTH_FRONTEND_LOGOUT: `${environment.authFrontendLogout}`,
      a5AUTH_REFRESH_SESSION_TOKEN: `${environment.authRefreshSessionToken}`
    }},
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
    { provide: UrlSerializer, useClass: CustomUrlSerializer  },
    { provide: Window, useValue: window },
    { provide: Location, useValue: location }
  ],
  bootstrap: [AppComponent],
})
export class AppModule { }
