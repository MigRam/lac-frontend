import { Component } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { faBook, faCogs, faFileUpload, faHome, faSignInAlt } from '@fortawesome/free-solid-svg-icons';
import { faPlayCircle } from '@fortawesome/free-regular-svg-icons';

@Component({
  selector: 'lac-root',
  templateUrl: './app.component.html',
  styles: [],
})
export class AppComponent {
  title = 'lac-portal';

  faHome = faHome;
  faBook = faBook;
  faSignIn = faSignInAlt;
  faDeposit = faFileUpload;
  faApplication = faCogs;
  faPlayer = faPlayCircle;

  links = [
    { path: "/", label: "Home", icon: this.faHome },
    { path: "/docs", label: "User Guides", icon: this.faBook },
  ];

  authLinks = [
    { path: "/", label: "Home", icon: this.faHome },
    { path: "/docs", label: "User Guides", icon: this.faBook },
    { path: "/deposit", label: "Deposit", icon: this.faDeposit },
    { path: '/elan-player', label: 'ELAN-Player', icon: this.faPlayer }
  ];  

  constructor(
    private pageTitle: Title,
    ) {
    this.pageTitle.setTitle('LAC - Language Archive Cologne');
  }
}
