// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  name: 'environment-development',
  production: false,
  api: 'https://grails-dev.rrz.uni-koeln.de/ka3-api',
  authLogin: '/login',
  authValidate: '/validate',
  authFrontend: 'https://grails-dev.rrz.uni-koeln.de/ka3-pub',
  authFrontendLogin: 'https://grails-dev.rrz.uni-koeln.de/ka3-pub/authentication/login',
  authFrontendLogout: 'https://grails-dev.rrz.uni-koeln.de/ka3-pub/saml/logout',
  authRefreshSessionToken: 'https://grails-dev.rrz.uni-koeln.de/ka3-pub/authentication/token',
  queryApi: '/query',
  objectApi: '/object',
  oai: '/oai',
  mediApi: '/media',
  annotationApi: '/annotation',
  depositApi: '/deposit',
  downloadApi: 'https://grails-dev.rrz.uni-koeln.de/ka3-download',
  ingestApi: 'https://grails-dev.rrz.uni-koeln.de/ka3-ingest',
  webdavApi: 'https://grails-dev.rrz.uni-koeln.de/ka3-dav',
  repository: '/lac'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
