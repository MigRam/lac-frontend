import { InjectionToken } from '@angular/core';
export const APP_ENVIRONMENTS_CONFIG = new InjectionToken('application_environments');
