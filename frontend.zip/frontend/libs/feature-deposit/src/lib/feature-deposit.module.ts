import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DepositRoutingModule } from './deposit-routing.module';

@NgModule({
  imports: [CommonModule, DepositRoutingModule],
  declarations: [DashboardComponent],
})
export class FeatureDepositModule {}
