export { FeatureDepositModule } from './lib/feature-deposit.module';
