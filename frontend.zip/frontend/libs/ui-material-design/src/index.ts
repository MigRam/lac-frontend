export { UiMaterialDesignModule } from './lib/ui-material-design.module';
