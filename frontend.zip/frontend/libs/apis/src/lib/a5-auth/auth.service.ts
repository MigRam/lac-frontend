import { Inject, Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from "@angular/router";
import { APP_ENVIRONMENTS_CONFIG } from '@lac/config';
import { Auth, User } from './auth.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  
  constructor(
    private router: Router,
    private location: Location,
    private snackbar: MatSnackBar,
    private childWindow: Window,
    @Inject(APP_ENVIRONMENTS_CONFIG) private config: any
  ) {
  }

  private _createAuthentication(user: User, isAuth: boolean): Auth {
    const lacUser = {
      user: user,
      isAuthenticated: isAuth,
    }

    localStorage.isAuth = lacUser.isAuthenticated;
    localStorage.AccessToken = lacUser.user.access_token;
    localStorage.Username = lacUser.user.username;

    return lacUser as Auth;
  }

  private _windowRef(endpoint, id?) {
    this.childWindow = window.open(endpoint, id, 'status=no,toolbar=yes,scrollbars=yes,resizable=no,left=350,width=1200,height=900');
  }

  private _receiveMessage(event: any) {
    event.preventDefault();
    this._createAuthentication(event['data'], true);
    this.childWindow.close();
    this.router.navigate(['/'], { skipLocationChange: true });
    this.location.reload();
    this.snackbar.open('Welcome', this.getAuthUser(), {
      duration: 3000
    });
  }


  /* Frontend Login */
  login() {
    this._windowRef(`${this.config.a5AUTH_FRONTEND_LOGIN}?origin=${location.href}/&messageId`, 'authentication');

    if (window.addEventListener) {
      window.addEventListener("message", this._receiveMessage.bind(this), { once: true });
    } else {
      (<any>window).attachEvent("onmessage", this._receiveMessage.bind(this), { once: true });
    }

  }

  logout() {

    localStorage.clear();
    this._windowRef(`${this.config.a5AUTH_FRONTEND_LOGOUT}`, 'authentication');

     setTimeout(() => {
       this.snackbar.open('You are successfully logged out', '', {
         duration: 3000,
         data: this.childWindow.close()
     });
     this.router.navigate(['/'], {skipLocationChange: true});
     this.location.reload();
    }, 2000);
    

  }

  reloadCurrentRoute() {
    let currentUrl = this.router.url;
    this.router.navigate([], { skipLocationChange: true })
      .then(() => {
        this.router.navigated = false;
        this.router.navigate([currentUrl]);
      });
  }

  getAuthStatus() {
    return localStorage.getItem('isAuth');
  }

  getAuthToken() {
    return localStorage.getItem('AccessToken');
  }

  getAuthUser() {
    return localStorage.getItem('Username');
  }

}