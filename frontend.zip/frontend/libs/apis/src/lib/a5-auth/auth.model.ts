
export interface Credentials {
  username: string;
  password: string;
}

export interface Depositor {
  role: string;
  uploadData();
}

export interface Admin {
  role: string;
  setRoles();
}

export interface User {
  username: string,
  cn?: string,
  mail?: string,
  roles: Depositor | Admin,
  token_type: string,
  access_token: string,
  expires_in: number,
  session_expires_in?: string,
  refresh_token?: string
}

export interface Auth {
  user: User;
  isAuthenticated: boolean;
}