import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from './auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(
    private router: Router,
    private authSvc: AuthService,
    private snackbar: MatSnackBar
  ) {
  }

  canActivate(): boolean {
    if (this.authSvc.getAuthStatus()) {
      return true;
    }

    this.snackbar.open('LAC: Authentication required', 'Please login!', {
      duration: 3000,
      data: this.router.navigateByUrl('/'),
      panelClass: 'lac-login-error'
    });

    return false;
  }
}
