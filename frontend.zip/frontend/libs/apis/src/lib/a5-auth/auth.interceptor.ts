import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { AuthService } from './auth.service';
import { catchError, tap } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(
    private authSvc: AuthService,
    private snackbar: MatSnackBar
  ) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    const authToken = this.authSvc.getAuthToken()

    const authRequest = request.clone({ headers: request.headers.set('Authorization', `Bearer ${authToken}`) }); 
   
     if (authToken) {
       return next.handle(authRequest).pipe(tap(console.log))
     } 

    return next.handle(request)
      .pipe(
        catchError( error => {
          if(error.status === '401') {
            this.snackbar.open('LAC: Authentication required', 'Please login!', {
              duration: 3000,
              panelClass: 'lac-login-error'
            });
            console.info(error.statusText);
          }
          const errorMsg = error.error.message || error.statusText;
          return throwError(errorMsg);
        })
      )
  }

}
