import { Directive, Input, OnDestroy, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { AuthService } from './auth.service';

@Directive({
  selector: '[lacUserStatus]'
})
export class authStatusDirective implements OnInit, OnDestroy {

  @Input() lacUserStatus: boolean;

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private authSvc: AuthService
  ) { }

  ngOnInit(): void {
   this.getAuthStatus();
  }

  getAuthStatus () {
    this.viewContainer.clear();
    const isAuth = this.authSvc.getAuthStatus();
    if(isAuth) {
      if (this.lacUserStatus) {
        this.viewContainer.createEmbeddedView(this.templateRef);
      } else {
        this.viewContainer.clear();
      }
    } else {
      if (this.lacUserStatus) {
        this.viewContainer.clear();
      } else {
        this.viewContainer.createEmbeddedView(this.templateRef);
      }
    }
  }

  ngOnDestroy(): void {

  }

}
