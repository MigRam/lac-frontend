import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(
    private http: HttpClient
  ) { }


  fetch(endpoint?: string, selectors?: any) {
    return this.http.request('GET', endpoint, {
      params: new HttpParams({ fromString: selectors?.toString() }),
      reportProgress: true
    })
  }

  post(endpoint: string, data: any) {
    const options = {
      headers: new HttpHeaders().set('Content-Type', 'application/json')
    }
    return this.http.post(endpoint, JSON.stringify(data), options);
  }

  update(endpoint: string, data: any) {
    return this.http.patch(endpoint, data);
  }

  delete(id: string) {
    return this.http.request('DELETE', `${id}`);
  }

  apiError(response: HttpErrorResponse) {
    if (response.error instanceof ErrorEvent) {
      console.error(`Client or Network error occurred:, ${response.error.message}`);
    } else {
      console.error(`Backend error occurred: ${response.status}, ` + `body was: ${response.error}`);
    }
    return throwError(response.error || ' @ERROR: ' + response)
  }

}
