
export type SelectorNumber = string | number;

export type SelectorBoolean = string | boolean;

export type SelectorFilter = string | Array<string>;

export type SelectorString = boolean | number | string;

export type SelectorStringArray = string | Array<string>;
