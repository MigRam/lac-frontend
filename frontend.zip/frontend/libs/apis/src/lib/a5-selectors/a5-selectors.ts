import { HttpParams } from "@angular/common/http";
import { AUTOCOMPLETE, COUNT, FACETS, FIELDS, FILTER, HIGHLIGHT, PRETTY, SEARCH, SELECT, TOP } from './odata-selectors';

const HTTP_PARAMS = new HttpParams();

export const querySelectors = (searchValue = '*') => {
    return HTTP_PARAMS
        .set(SEARCH, searchValue)
        .append(COUNT, 'true')
        .append(HIGHLIGHT, 'true')
        .append(PRETTY, 'true')
}

export const queryFieldsAndFacets = (entries, facets, counts) => {
    return HTTP_PARAMS
        .set(TOP, counts)
        .append(SELECT, entries)
        .append(FACETS, facets)
        .append(FILTER, 'MetadataType ne BundleTranslation')
}

export const autocompletes = (searchValue) => {
    return HTTP_PARAMS
        .set(SEARCH, searchValue)
        .append(AUTOCOMPLETE, 'true')
        .append(TOP, '0')
        .append(PRETTY, 'true')
}

export const filter = (token, operator, value) => {
    return HTTP_PARAMS
        .set(FILTER, `${token} ${operator} ${value}`)
        .append(HIGHLIGHT, 'true')
        .append(COUNT, 'true')
        .append(PRETTY, 'true');
}

export const fetchAll = () => {
    return HTTP_PARAMS
        .set(SEARCH, '*')
        .append(COUNT, 'true')
        .append(TOP, '0')
        .append(FILTER, 'MetadataType ne BundleTranslation');
}

export const fetchFields = (fields, counts) => {
    return HTTP_PARAMS
    .set(TOP, counts)
    .append(FIELDS, fields)
    .append(FILTER, 'MetadataType ne BundleTranslation')
}

export const fetchFacets = (facets) => {
    return HTTP_PARAMS
    .append(FACETS, facets)
    .append(TOP, '0')
    .append(FILTER, 'MetadataType ne BundleTranslation')
}
