export const SEARCH = '$search';

export const AUTOCOMPLETE = 'autocomplete';

export const TOP = '$top';

export const HIGHLIGHT = 'highlight';

export const COUNT = '$count';

export const EXPAND = '$expand';

export const PRETTY = 'pretty';

export const DRILL = 'drill';

export const FILTER = '$filter';

export const FACETS = 'facets';

export const FIELDS = 'fields';

export const SELECT = '$select';

export const ORDERBY = '$orderby';

export const SKIP = '$skip';
