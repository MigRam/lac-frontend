import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { authStatusDirective } from './a5-auth/auth-status.directive';

@NgModule({
  imports: [CommonModule],
  declarations: [ authStatusDirective ],
  exports: [ authStatusDirective ],
  providers: [],
  entryComponents: [ ]
})
export class ApisModule { }
