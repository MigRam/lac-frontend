import { A5QueryApiEntity } from './a5-query-api-entity';

export class A5QueryApiEntityCollection {

    a5Autocomplete: any;
    a5Selector: any;
    odataContext: any;
    odataNextLink: any;
    odataCount: any;
    value = [];
    a5Facets = [];

    constructor(json: any) {
       this.a5Autocomplete = json['@a5.autocomplete'];
       this.a5Selector = json['@a5.selector'];
       this.odataContext = json['@odata.context'];
       this.odataNextLink = json['@odata.nextLink'];
       this.odataCount = json['@odata.count'];
       json['value'].map(value => 
        this.value.push(new A5QueryApiEntity(value))
        );

       for(let facet in json["@a5.facets"]) {
        let obj: any = new Object();
        obj.faceName = facet;
        obj.buckets = json["@a5.facets"][facet].buckets
        obj.hasMoreBuckets = (json["@a5.facets"][facet].sum_other_doc_count > 0);
        this.a5Facets.push(obj);
      }

    }

    get autocompletes() {
        return this.a5Autocomplete ? this.a5Autocomplete['autocomplete']['buckets'] : null;
    }

    get dataset() {
        return this.value;
    }

    get facets() {
        return this.a5Facets;
    }

}
