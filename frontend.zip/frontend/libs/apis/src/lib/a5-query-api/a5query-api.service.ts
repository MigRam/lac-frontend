import { HttpParams } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { APP_ENVIRONMENTS_CONFIG } from '@lac/config';
import { Observable } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { autocompletes, filter, querySelectors, fetchAll, fetchFacets, fetchFields } from '../a5-selectors/a5-selectors';
import { ApiService } from '../services/api.service';
import { A5QueryApiEntityCollection } from './a5-query-api-entity-collection';

@Injectable({
  providedIn: 'root'
})
export class A5QueryApiService {

  constructor(
    private apiSvc: ApiService,
    private router: Router,
    @Inject(APP_ENVIRONMENTS_CONFIG) private config: any
  ) {
  }

  query(selectorsToString: HttpParams): Observable<A5QueryApiEntityCollection> {
    return this.apiSvc.fetch(this.config.a5QUERY, selectorsToString)
      .pipe(
        tap(console.log),
        map(response => new A5QueryApiEntityCollection(response)),
        // tap(console.log),
        catchError(this.apiSvc.apiError)
      )
  }

  search(inputValue) {
    this.router.navigate(['/'], { 
       queryParams: { 'query': inputValue },
       replaceUrl: true
    });
    return this.query(querySelectors(inputValue));
  }

  autocompletes(inputValue) {
    return this.query(
      autocompletes(inputValue));
  }

  filterById(id) {
    return this.query(
      filter('id', 'eq', id)
    )
  }

  fetchAll() {
    return this.query(
      fetchAll()
      )
  }

  fetchFields(fields, counts) {
    return this.query(
      fetchFields(fields, counts)
    )
  }

  fetchFacets(facets) {
    return this.query(
      fetchFacets(facets)
    )
  }

}
