export class A5QueryApiEntity {

    a5Highlight = [];
    id?: string;
    MetadataType?: string;
    Title?: string;
    AccessLevel?: string;
    Description?: Array<string>;
    ObjectLanguage?: string;
    IsPartOf?: string;
    Keywords?: Array<string>;
    ProjectName?: string;
    ProjectDescription?: string;
    Location?: string;
    Country?: string;
    Region?: string;
    GeoLocation?: string;
    LegacyBlob?: string;
    Creator?: string;
    RecordingDate?: string;
    ResourceType?: Array<string>;
    ResourceMimeType?: Array<string>;
    MetadataObject?: Array<string>;

    constructor(entity: any) {

        // this.a5Highlighs = entity['@a5.highlight'];
        this.id = entity['id'];
        this.MetadataType = entity['MetadataType'];
        this.Title = entity['Title'];
        this.AccessLevel = entity['accessLevel'];
        this.Description = entity['Description'];
        this.ObjectLanguage = entity['ObjectLanguage'];
        this.IsPartOf = entity['IsPartOf'];
        this.Keywords = entity['Keywords'];
        this.ProjectName = entity['ProjectName'];
        this.ProjectDescription = entity['ProjectDescription'];
        this.GeoLocation = entity['GeoLocation'];
        this.Location = entity['Location'];
        this.Country = entity['Country'];
        this.Region = entity['Region'];
        this.LegacyBlob = entity['LegacyBlob'];
        this.Creator = entity['Creator'];
        this.RecordingDate = entity['RecordingDate'];
        this.ResourceType = entity['ResourceType'];
        this.ResourceMimeType = entity['ResourceMimeType'];
        this.MetadataObject = entity['MetadataObject'];
        this.a5Highlight = entity["@a5.highlight"];
    }

    get highlights() {
        return this.a5Highlight;
    }

    get type() {
        return this.MetadataType;
    }

    get title() {
        return this.Title;
    }

    get accessLevel() {
        return this.AccessLevel;
    }

    get description() {
        return this.Description || '<no description available>';
    }

    get shortDescription() {
        return this.Description.toString().split(".")[0];
    }

    get geolocation() {
        return this.GeoLocation;
    }

    get languages() {
        return this.ObjectLanguage;
    }

    get keywords() {
        return this.Keywords;
    }

    get country() {
        return this.Country;
    }

    get location() {
        return this.Location;
    }

    get region() {
        return this.Region;
    }

    get projectName() {
        return this.ProjectName;
    }

    get projectDescription() {
        return this.ProjectDescription;
    }

    get resourceMimeType() {
        return this.ResourceMimeType;
    }

    get resourceType() {
        return this.ResourceType;
    }

    get metadataObject() {
        return this.MetadataObject;
    }

    get routeId() {
        return this.id ? this.id[0].replace('hdl:', '') : this.id.replace('hdl:', '');
    }

    get routePrefix() {
        if (this.type === 'BundleTranslation') {
            return 'bundle';
        }
        return this.type.toString().toLowerCase();
    }

    get routeParent() {
        if (this.IsPartOf) {
            return this.IsPartOf ? this.IsPartOf[0].replace('hdl:', '') : this.IsPartOf.replace('hdl:', '');
        }
    }

    get isCollection() {
        return this.type == 'Collection';
    }

    get isBundle() {
        return this.type == 'Bundle';
    }
}
