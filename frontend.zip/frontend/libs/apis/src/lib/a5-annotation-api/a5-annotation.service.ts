import { Injectable, Inject } from '@angular/core';
import { ApiService } from '../services/api.service';
import { APP_ENVIRONMENTS_CONFIG } from '@lac/config';
import { Observable } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { OdataEntityManifest } from './odata-entity-manifest';
import { OdataEntityCanvas } from './odata-entity-canvas';
import { OdataEntityAnnotationLayer } from './odata-entity-annotation-layer';
import { HttpParams } from '@angular/common/http';
import { OdataCollectionAnnotation } from './odata-collection-annotation';

@Injectable({
  providedIn: 'root'
})
export class A5AnnotationService {

  constructor(
    private apiSvc: ApiService,
    @Inject(APP_ENVIRONMENTS_CONFIG) private config: any
  ) { }

  fetchAnnotationManifest(id: string, selector: HttpParams): Observable<OdataEntityManifest> {
    return this.apiSvc.fetch(`${this.config.ANNOTATION}/Manifest(${id})`, selector)
      .pipe(
        map(response => new OdataEntityManifest(response)),
        catchError(this.apiSvc.apiError)
      )
  }

  fetchAnnotationCanvas(id: string, selector: HttpParams): Observable<OdataEntityCanvas> {
    return this.apiSvc.fetch(`${this.config.ANNOTATION}/Canvas(${id})`, selector)
      .pipe(
        map(response => new OdataEntityCanvas(response)),
        catchError(this.apiSvc.apiError)
      )
  }

  fetchAnnotationLayer(selector: HttpParams): Observable<OdataEntityAnnotationLayer> {
    return this.apiSvc.fetch(`${this.config.ANNOTATION}/Layers`, selector)
      .pipe(
        tap(console.log),
        map(response => new OdataEntityAnnotationLayer(response)),
        catchError(this.apiSvc.apiError)
      )
  }

  fetchAnnotationLayerById(id: string, selector: HttpParams): Observable<OdataEntityAnnotationLayer> {
    return this.apiSvc.fetch(`${this.config.ANNOTATION}/Layer(${id})`, selector)
      .pipe(
        map(response => new OdataEntityAnnotationLayer(response)),
        catchError(this.apiSvc.apiError)
      )
  }

  fetchAnnotations(selector: HttpParams): Observable<OdataCollectionAnnotation> {
    return this.apiSvc.fetch(this.config.ANNOTATION, selector)
    .pipe(
      map(response => new OdataCollectionAnnotation(response)),
      catchError(this.apiSvc.apiError)
    )

}
