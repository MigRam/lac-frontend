import { ODataEntity } from './odata';
import { OdataEntityAnnotation } from './odata-entity-annotation';

export class OdataEntityAnnotationLayer extends ODataEntity {
    id: string;

    label: string;

    type: Array<string>;

    resources: Array<OdataEntityAnnotation>;

    hasParent: string;

    isParentOf: Array<string>;

    constructor(json: any) {
        super(json);
        this.id = json["id"];
        this.label = json["label"];
        this.type = json["type"];
        this.resources = ODataEntity.expand(json["resources"], OdataEntityAnnotation);
        this.hasParent = json["hasParent"];
        this.isParentOf = json["isParentOf"];
    }
}
