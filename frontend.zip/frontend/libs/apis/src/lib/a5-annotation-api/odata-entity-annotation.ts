import { ODataEntity } from './odata';

export class OdataEntityAnnotation extends ODataEntity {
    id: string;

    label: string;

    type: Array<string>;

    bodyValue: string;

    selector: any;

    target: string;

    constructor(json: any) {
        super(json);
        this.id = json["id"];
        this.label = json["label"];
        this.type = json["type"];
        this.bodyValue = json["bodyValue"];
        this.selector = json["selector"];
        this.target = json["target"];
    }
}
