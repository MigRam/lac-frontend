import { ODataEntity } from './odata';
import { OdataEntityAnnotationLayer } from './odata-entity-annotation-layer';
import { OdataEntityObject } from './odata-entity-object';

export class OdataEntityCanvas extends ODataEntity {
    id: string;

    label: string;

    type: Array<any>;

    duration: number;

    media: Array<any>;

    otherContent: Array<any>;

    constructor(json: any) {
        super(json);
        this.id = json["id"];
        this.label = json["label"];
        this.type = json["type"];
        this.duration = json["duration"];
        this.media = ODataEntity.expand(json["media"], OdataEntityObject);
        this.otherContent = ODataEntity.expand(json["otherContent"], OdataEntityAnnotationLayer);
    }
}
