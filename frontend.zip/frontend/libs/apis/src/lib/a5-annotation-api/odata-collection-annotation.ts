import { OdataCollection } from "../a5-core/odata-collection";
import { OdataEntityAnnotation } from "./odata-entity-annotation";

export class OdataCollectionAnnotation extends OdataCollection {

  value: Array<OdataEntityAnnotation> = [];

  a5Facets: any = [];

  constructor(json: any) {
    super(json);
    for(const entity of json.value) {
      this.value.push(new OdataEntityAnnotation(entity));
    }
    for(const facet in json["@a5.facets"]) {
     if(facet) {
      const obj: any = {};
      obj.faceName = facet;
      obj.buckets = json["@a5.facets"][facet].buckets
      obj.hasMoreBuckets = (json["@a5.facets"][facet].sum_other_doc_count > 0);
      this.a5Facets.push(obj);
     }
    }
  }
}
