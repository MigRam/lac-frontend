import { ODataEntity } from './odata';
import { OdataEntityCanvas } from './odata-entity-canvas';
import { OdataEntityObject } from './odata-entity-object';

export class OdataEntityManifest extends ODataEntity {
    id: string;

    label: string;

    type: Array<string>;

    members: Array<any>;

    within: Array<any>;

    constructor(json: any) {
        super(json);
        this.id = json["id"];
        this.label = json["label"];
        this.type = json["type"];
        this.members = ODataEntity.expand(json["members"], OdataEntityCanvas);
        this.within = ODataEntity.expand(json["within"], OdataEntityObject);
    }
}
