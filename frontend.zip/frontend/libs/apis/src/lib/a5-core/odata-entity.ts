export class OdataEntity {
    constructor(json: any) {
        console.log(json);
    }
}
