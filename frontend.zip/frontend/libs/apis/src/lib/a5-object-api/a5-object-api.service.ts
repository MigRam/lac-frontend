import { HttpParams } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { APP_ENVIRONMENTS_CONFIG } from '@lac/config';
import { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { ApiService } from '../services/api.service';

@Injectable({
  providedIn: 'root'
})
export class A5ObjectApiService {

  constructor(
    private apiSvc: ApiService,
    @Inject(APP_ENVIRONMENTS_CONFIG) private config: any
  ) { }

  getObject(id, selectorStringSet: HttpParams): Observable<any> {
    return this.apiSvc.fetch(`${this.config.a5OBJECT}/Object(${id})`, selectorStringSet)
      .pipe(
        map(response => response),
        catchError(this.apiSvc.apiError)
      )
  }

  getObjects(selectorStringSet: HttpParams): Observable<any> {
    return this.apiSvc.fetch(`${this.config.a5OBJECT}/Objects`, selectorStringSet)
      .pipe(
        map(response => response),
        catchError(this.apiSvc.apiError)
      )
  }
}
