export { FeatureDiscoveryModule } from './lib/feature-discovery.module';
