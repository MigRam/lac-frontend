import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { debounceTime, distinctUntilChanged, tap } from 'rxjs/operators';
import { DiscoveryService } from '../discovery-shared/discovery.service';

@Component({
  selector: 'lac-discovery',
  templateUrl: './discovery.component.html',
  styleUrls: ['./discovery.component.css']
})
export class DiscoveryComponent implements OnInit, OnDestroy {
  
  queryInput: FormControl = new FormControl();
  inProgress: boolean;

  constructor(
    public discovery: DiscoveryService,
  ) {
    const query$ = this.queryInput
      .valueChanges
      .pipe(
        tap(() => this.inProgress = true),
        debounceTime(100),
        distinctUntilChanged()
      )

    query$.subscribe((val) => {
      this.inProgress = false;
      this.discovery.fetchAutocompletes(val);
    })

  }

  ngOnInit() {
    this.discovery.fetchDiscoveryData();    
  }

  ngOnDestroy() {

  }

  clearInput() {
    this.queryInput.setValue('');
  }

}
