import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DiscoveryService } from '../discovery-shared/discovery.service';
import { Title, Meta } from '@angular/platform-browser';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'lac-discovery-collection',
  templateUrl: './discovery-collection.component.html',
  styleUrls: ['./discovery-collection.component.scss']
})
export class DiscoveryCollectionComponent implements OnInit {
  collectionData$: Observable<any>;
  constructor(
    private router: Router,
    public discoverySvc: DiscoveryService,
    private pageTitle: Title,
    private meta: Meta
  ) { }

  ngOnInit(): void {
    const collectionId = this.router.url.replace('/collection/', 'hdl:');
    this.collectionData$ = this.discoverySvc.filterById(collectionId)
    .pipe(
      tap( (response) => {
        const collection = response.value[0];     
        
        const collectionUrl = this.router.url;

        this.pageTitle.setTitle(`LAC Collection - ${collection.ID}`);
        
        this.meta.addTags( [
          {name: 'collection', content: collection.Title}, 
          {name: 'metadataType', content: collection.MetadataType},
          {name: 'description', content: collection.Description }, 
          {name: 'keywords', content: collection.Keywords}
        ] );
        
        this.discoverySvc.generateJSONLD(collection, collectionUrl, collectionUrl);     

      })
    )
    // this.collectionBundles$ = this.discoverySvc.queryObject(collectionId);
  }

}
