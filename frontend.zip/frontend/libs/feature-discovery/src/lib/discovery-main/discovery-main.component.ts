import { Component, OnInit } from '@angular/core';
import { DiscoveryService } from '../discovery-shared/discovery.service';

@Component({
  selector: 'lac-discovery-main',
  templateUrl: './discovery-main.component.html',
  styleUrls: ['./discovery-main.component.scss']
})
export class DiscoveryMainComponent implements OnInit {

  constructor(
    public discovery: DiscoveryService
  ) { }

  ngOnInit(): void {
  }

}
