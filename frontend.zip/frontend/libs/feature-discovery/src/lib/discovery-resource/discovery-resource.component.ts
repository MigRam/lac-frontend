import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lac-discovery-resource',
  templateUrl: './discovery-resource.component.html',
  styleUrls: ['./discovery-resource.component.scss']
})
export class DiscoveryResourceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
