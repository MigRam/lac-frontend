import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { tap } from 'rxjs/operators';
import { DiscoveryService } from '../discovery-shared/discovery.service';
import { Observable } from 'rxjs';
import { faUnlock } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'lac-discovery-bundle',
  templateUrl: './discovery-bundle.component.html',
  styleUrls: ['./discovery-bundle.component.scss']
})
export class DiscoveryBundleComponent implements OnInit {

  bundle$: Observable<any>;
  faUnLock = faUnlock;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private pageTitle: Title,
    private meta: Meta,
    public discovery: DiscoveryService
  ) { }

  ngOnInit(): void {
    const id = this.router.url.replace('/bundle/', 'hdl:');
    this.bundle$ = this.discovery.filterById(`id eq ${id}`)
      .pipe(
        tap((response) => {
                
          const bundle = response.dataset[0];

          const bundleUrl = this.router.url;

          this.pageTitle.setTitle(`LAC Bundle - ${bundle.ID}`);

          this.meta.addTags([
            { name: 'bundle', content: bundle.Title },
            { name: 'metadataType', content: bundle.MetadataType },
            { name: 'description', content: bundle.Description },
            { name: 'keywords', content: bundle.Keywords }
          ]);

          this.discovery.generateJSONLD(bundle, bundleUrl, bundleUrl);

        })
      );
  }

}
