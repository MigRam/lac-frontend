import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { UiMaterialDesignModule } from '@lac/ui-material-design';
import { UiPipesModule } from '@lac/ui-pipes';
import { DiscoveryService } from './discovery.service';
import { FacetsbarComponent } from './facetsbar/facetsbar.component';
import { SearchHitsComponent } from './search-hits/search-hits.component';

@NgModule({
  declarations: [
    FacetsbarComponent, 
    SearchHitsComponent
  ],
  imports: [
    CommonModule,
    UiMaterialDesignModule,
    ReactiveFormsModule,
    FontAwesomeModule,
    FormsModule,
    UiPipesModule
  ],
  exports: [ 
      FacetsbarComponent, 
      SearchHitsComponent
  ],
  providers: [ DiscoveryService ]
})
export class DiscoverySharedModule { }
