import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { faArchive, faFile } from '@fortawesome/free-solid-svg-icons';
import { DiscoveryService } from '../discovery.service';

@Component({
  selector: 'lac-search-hits',
  templateUrl: './search-hits.component.html',
  styleUrls: ['./search-hits.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchHitsComponent {

  faArchive = faArchive;
  faFile = faFile;

  @Input() hits;

  constructor(
    public discovery: DiscoveryService
  ) {

  }

}
