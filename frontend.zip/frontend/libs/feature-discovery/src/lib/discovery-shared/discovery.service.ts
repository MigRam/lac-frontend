import { Injectable } from '@angular/core';
import { A5QueryApiService } from '@lac/apis';
import { Observable, Subscription } from 'rxjs';
import { tap, pluck } from 'rxjs/operators';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { Router } from '@angular/router';

const F_LANGUAGE = "ObjectLanguage";
const F_COUNTRY = "Country";
const F_KEYWORDS = "Keywords";
const F_RESOURCETYPE = "ResourceType";
const F_RESOURCEMIMETYPE = "ResourceMimeType";
const F_METADATATYPE = "MetadataType";
const R_REGION = "Region";

@Injectable({
  providedIn: 'root'
})
export class DiscoveryService {

  data$: Observable<any>;
  map$: Observable<any>;
  facets$: Observable<any>;

  autocompletes$: Observable<any>;
  jsonLD: SafeHtml;

  constructor(
    private a5Query: A5QueryApiService,
    private sanitizer: DomSanitizer,
    private router: Router
  ) {
  }

  fetchDiscoveryData() {
    const all = this.a5Query
      .fetchAll()
      .pipe(
        pluck('odataCount')
      );

    all.subscribe(counts => {

      const DISCOVERY_FACETS = `${F_LANGUAGE}:${counts},${F_COUNTRY}:${counts},${R_REGION}:${counts},${F_KEYWORDS}:${counts},${F_RESOURCEMIMETYPE}:${counts},${F_METADATATYPE}:${counts}`

      this.map$ = this.a5Query.fetchFields('GeoLocation,id', counts);

      this.facets$ = this.a5Query.fetchFacets(DISCOVERY_FACETS);
    })
  }

  search(inputValue) {
    this.data$ = this.a5Query.search(inputValue);
    this.map$ = this.a5Query.search(inputValue);   
  }

  fetchAutocompletes(inputValue) {
    this.autocompletes$ = this.a5Query.autocompletes(inputValue);
  }

  filterById(id) {
    return this.a5Query.filterById(id);
  }

  generateJSONLD(data, originUrl, originHost) {

    const handelUrl = data['id'].toString().substring(4);

    const lacDataSchema = {
      "@context": "https://schema.org/",
      "@type": "Dataset",
      "@id": "https://hdl.handle.net/" + handelUrl,
      "name": data['Title'],
      "description": data['Description'],
      "url": originUrl,
      "publisher": {
        "@type": "Organization",
        "name": "Language Archive Cologne",
        "@id": originHost
      },
      "license": "https://creativecommons.org/licenses/by-sa/4.0",
      "datePublished": "",
      "creator": [
        {
          "@type": data['Creator'],
          "givenName": "",
          "familyName": "",
          "name": "",
          "affiliation": "",
          "identifier": {
            "@type": "",
            "propertyID": "",
            "value": ""
          }
        }

      ],
      "keywords": [
        data['ObjectLanguage'],
        data['Country'],
        data['Region']
      ]
    };

    this.jsonLD = lacDataSchema ? JSON.stringify(lacDataSchema, null, 2).replace(/\//g, '\\/') : '';

    return this.sanitizer.bypassSecurityTrustHtml(`${this.jsonLD}`);
  }

  navigate(view, item) {
    switch (view) {
      case 'Collection':
        this.router.navigateByUrl(`/collection/${item.routeId}`);
        break;
      case 'Bundle':
        this.router.navigateByUrl(`/bundle/${item.routeId}`);
        break;
      default:
        this.router.navigateByUrl(`/${view}/${item.routeId}`);
        break;
    }
  }

}

