import { Component, OnInit, Input } from '@angular/core';
import { DiscoveryService } from '../discovery.service';

@Component({
  selector: 'lac-facetsbar',
  templateUrl: './facetsbar.component.html',
  styleUrls: ['./facetsbar.component.scss']
})
export class FacetsbarComponent implements OnInit {

 
  @Input() data;
  @Input() active: boolean;
  @Input() title: string;

  list = 3;
  listItem;

  constructor(
    private discovery: DiscoveryService
  ) { }

  ngOnInit(): void {
  }

  search(facet) {
    console.log(facet);
  }

  toggle() {
    this.active = !this.active;
  }

  trackListItem(id, el) {
    return this.listItem ? el.id : undefined;
  }

}
