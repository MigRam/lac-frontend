import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FacetsbarComponent } from './facetsbar.component';

describe('FacetsbarComponent', () => {
  let component: FacetsbarComponent;
  let fixture: ComponentFixture<FacetsbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FacetsbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FacetsbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
