import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Route, RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { UiMapModule } from '@lac/ui-map';
import { UiMaterialDesignModule } from '@lac/ui-material-design';
import { UiPipesModule } from '@lac/ui-pipes';
import { DiscoveryBundleComponent } from './discovery-bundle/discovery-bundle.component';
import { DiscoveryCollectionComponent } from './discovery-collection/discovery-collection.component';
import { DiscoveryMainComponent } from './discovery-main/discovery-main.component';
import { DiscoveryResourceComponent } from './discovery-resource/discovery-resource.component';
import { DiscoverySharedModule } from './discovery-shared/discovery-shared.module';
import { DiscoveryComponent } from './discovery/discovery.component';

export const featureDiscoveryRoutes: Route[] = [
  {
    path: '', component: DiscoveryComponent, children: [
      { path: '', component: DiscoveryMainComponent },
      { path: 'bundle/:prefix/:id', component: DiscoveryBundleComponent },
      { path: 'collection/:prefix/:id', component: DiscoveryCollectionComponent },
      { path: 'resource/:prefix/:id', component: DiscoveryResourceComponent }]
  }
];

@NgModule({
  imports: [
    CommonModule,
    DiscoverySharedModule,
    UiMaterialDesignModule,
    UiPipesModule,
    UiMapModule,
    FormsModule,
    ReactiveFormsModule,
    FontAwesomeModule,
    RouterModule.forChild(featureDiscoveryRoutes)
  ],
  declarations: [
    DiscoveryComponent,
    DiscoveryMainComponent,
    DiscoveryBundleComponent,
    DiscoveryCollectionComponent,
    DiscoveryResourceComponent
  ],
  exports: [],
  providers: []
})
export class FeatureDiscoveryModule { }
