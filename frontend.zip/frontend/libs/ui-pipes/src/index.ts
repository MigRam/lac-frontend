export { UiPipesModule } from './lib/ui-pipes.module';
