import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HighlightPipe } from './highlight.pipe';
import { FormatTypePipe } from './format-type.pipe';
import { HumanFileSize } from './file-size.pipe';
import { SecondsToMinutesPipe } from './seconds-to-minutes.pipe';
import { XmlFormatPipe } from './xml-format.pipe';

@NgModule({
  imports: [CommonModule],
  declarations: [HighlightPipe, FormatTypePipe, HumanFileSize, SecondsToMinutesPipe, XmlFormatPipe],
  exports: [HighlightPipe, FormatTypePipe, HumanFileSize, SecondsToMinutesPipe, XmlFormatPipe]
})
export class UiPipesModule {}
