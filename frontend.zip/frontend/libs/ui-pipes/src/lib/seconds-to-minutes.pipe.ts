import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'secondsToMinutes'
})
export class SecondsToMinutesPipe implements PipeTransform {

  transform(time: number): string {
    const min = ('0' + Math.floor(time / 60)).slice(-2);
    const sec = ('0' + time % 60 ).slice(-2);
    return `${min}:${sec}`;
  }

}
