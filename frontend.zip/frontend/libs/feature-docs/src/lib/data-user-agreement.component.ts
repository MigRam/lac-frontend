import { Component } from '@angular/core';

@Component({
  template: `
    <section>
    <h1 class="mat-h1">Data User Agreement</h1>
    <p>
        Content Provider, operating through the CLARIN network has collected
        certain data (“CLARIN data”). Content Provider shall make these
        CLARIN data available, for the research user (“User”) subject to the
        terms of this Data User Agreement (“DUA”). By accepting this DUA,
        the User agrees to the conditions set out in this DUA and affirms
        that CLARIN data will be used for research and analysis purposes
        only, and that these data will be used solely for the purposes
        specified in the Application for use of restricted data from the
        CLARIN database (“Application”). By accepting the Application, the
        Content Provider authorizes the User and possible other researchers
        named in the Application, subject to the terms and conditions of
        this DUA a non-assignable limited term to use the CLARIN data for
        the purposes set forth in this DUA and the Application. Licensing
        and other terms between User and Content Provider and/or CLARIN will
        be agreed separately.
    </p>

    <h2 class="mat-h2">1. Research Use</h2>
    <p>
        The User agrees to use the CLARIN data only for the research
        purposes specified in this DUA and the attached Application. Any use
        not expressly described in the DUA or the Application is prohibited.
        Prohibited use includes, but is not limited to, any commercial or
        business use. Use of the CLARIN data for a research project other
        than the one described in the Application will not be undertaken
        until after a separate Application for that project has been
        submitted to, and approved by, the Content Provider.
    </p>

    <h2 class="mat-h2">2. Confidentiality</h2>
    <p>
        The User agrees to maintain the confidentiality of the CLARIN data,
        including not releasing, and prohibiting others from releasing, any
        information that identifies persons, directly or indirectly. User
        will ensure that the CLARIN data with identifiers are kept in a
        physically/electronically secured environment and access will be
        given only to authorized researchers as named in the Application.
        User shall not try to identify persons based on the CLARIN data
        obtained via this agreement, including through such means as linkage
        with other databases.
    </p>

    <h2 class="mat-h2">3. Non-Assignability and other researchers</h2>
    <p>
        Neither this agreement nor the use of the CLARIN data may be
        assigned by the Users to other persons without the prior written
        consent of the Content Provider. User agrees not to distribute,
        sell, or permit others to use the CLARIN data. The User shall not
        allow access to these CLARIN data in full or in part to any person
        without the separate written permission, unless these researchers
        are named in the Application and accepted by the Content Provider.
        The User agrees to inform these researchers who use the CLARIN data
        and are named in the Application about the policies and procedures
        related to this DUA. All researchers named in the Application
        working with the CLARIN data must comply with the provisions of this
        DUA. The User bears the ultimate responsibility for ensuring this
        compliance.
    </p>

    <h2 class="mat-h2">4. Reporting of Research</h2>
    <p>
        Reporting of research will be in aggregate, with all names and other
        personal individual identifiers expunged.
    </p>

    <h2 class="mat-h2">5. No Warranties</h2>
    <p>
        The CLARIN data is released “as is” without warranty of any kind.
        The entire risk of the quality and performance of the CLARIN data is
        assumed by the User. The User agrees that he or she will not hold,
        or attempt to hold, Content Provider or CLARIN responsible for any
        damages, including any incidental or consequential damages arising
        from the use of, or inability to access the requested CLARIN data
        files to the extent allowed by national law.
    </p>

    <h2 class="mat-h2">6. Termination</h2>
    <p>
        The term of this agreement and hence, the authorization to use the
        CLARIN data, is the shorter of two years from the date of accepting
        this agreement, or upon written notice of termination by the
        parties. Content Provider and/or CLARIN may terminate this agreement
        at any time for any reason by providing written notice by email to
        the User or to any one of researchers named in the Application.
    </p>
    <p>
        In addition, this agreement and the rights granted will terminate
        automatically upon any substantial breach by User or other
        researchers named in the Application of the terms of this agreement.
        At the time of termination of this agreement, the User agrees to
        destroy immediately the CLARIN data files. The provisions of the
        Application and the DUA that protect personal information survive
        the termination of this DUA as well as the termination or completion
        of the research project and the research thereunder.
    </p>

    <h2 class="mat-h2">7. Provisions relating to use by third parties</h2>
    <p>
        The Repository shall require third parties to whom the Content (or
        substantial parts thereof) is made available to include in the
        research results a clear reference to the Content from which data
        have been used. The reference must comply with the CLARIN
        Infrastructure Terms of Use.
    </p>

    <h2 class="mat-h2">8. Death of the Depositor</h2>
    <p>
        Following the death of the Depositor, or in the event that the
        Depositor's organization ceases to exist, the data will be treated
        according to the given copyright and privacy policy.
    </p>

    <h2 class="mat-h2">9. Liability</h2>
    <dl>
        <dd>
            The Repository accepts no liability in the event that all or part
            of Content is lost.
        </dd>
        <dd>
            The Repository accepts no liability for any damage or losses
            resulting from acts or omissions by third parties to whom the
            Repository has made Content available.
        </dd>
    </dl>

    <h2 class="mat-h2">10. Term and termination of the Agreement</h2>
    <dl>
        <dd>
            This Agreement shall come into effect on the date on which the
            Repository receives the Content (hereafter the deposit date) and
            shall remain valid for an indefinite period. Cancellation of this
            Agreement is subject to a period of notice of six months, and
            notice shall be given in writing. It is possible to change the
            agreed access category at any time during the term of the
            Agreement.
        </dd>
        <dd>
            Notwithstanding point (a), this Agreement shall end when Content
            is removed from the data archive in accordance with Article 5 of
            this Agreement.
        </dd>
        <dd>
            If the Repository ceases to exist or terminates its data-archiving
            activities, the Repository shall attempt to transfer the data
            files to a similar organisation that will continue the Agreement
            with the Depositor under similar conditions if possible.
        </dd>
    </dl>

    <h2 class="mat-h2">11. Applicable Law</h2>
    <p>
        German law is applicable to this agreement.
    </p>
    </section>
  `
})
export class DataUserAgreementComponent {

}
