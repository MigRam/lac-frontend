import { Component } from '@angular/core';

@Component({
  template: `
    <mat-toolbar color="warn">
      <mat-hint class="mat-small">{{documentsLinkDescription | uppercase}}</mat-hint>
      <button type="button" mat-button (click)="drawer.toggle()">
        <mat-icon>menu</mat-icon>
      </button>
    </mat-toolbar>
    <mat-sidenav-container class="mat-typography">
      <mat-sidenav #drawer mode="side">
        <mat-list dense>
          <mat-list-item *ngFor="let item of guides">
            <a mat-flat-button [routerLink]="item.path"  matTooltip="item.label" [innerHTML]="item.label"></a>
          </mat-list-item>
        </mat-list>
      </mat-sidenav>
      <mat-sidenav-content class="container">
          <div class="content">
            <router-outlet></router-outlet>
          </div>
      </mat-sidenav-content>
    </mat-sidenav-container>
  `,
  styles: [`
    mat-hint { color: #ffffff; }
    mat-icon { color: #ffffff; }
  `]
})
export class GuidesIndexComponent {
  documentsLinkDescription = 'List of all external documents';
  guides: any = [
    { label: 'User Guides', path: '/docs' },
    { label: 'Terms of Use', path: 'terms-of-use' },
    { label: 'Mission Statement', path: 'mission-statement' },
    { label: 'Depositor Agreement', path: 'depositor-agreement' },
    { label: 'Data User Agreement', path: 'data-user-agreement' },
    { label: 'Depositor Guidelines', path: 'depositor-guidelines' },
    { label: 'Submission Guidelines', path: 'submission-guidelines' },
    { label: 'Depositing Policy', path: 'depositing-policy' },
    { label: 'Format Whitelist', path: 'format-whitelist' },
    { label: 'Archive Setup', path: 'archive-setup' },
    { label: 'Privacy Policy', path: 'privacy-policy' }
  ];
}
