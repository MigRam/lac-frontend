import { Component } from '@angular/core';

@Component({
  template: `
      <section>
      <h1 class="mat-title">CLARIN Terms of Service</h1>
      <h2 class="mat-h2">Preamble</h2>
      <p>
        Welcome to the Language Archive Cologne (LAC) at the Data Center for the Humanities (DCH) CLARIN
        Centre  website. This repository service is provided to you by Data Center for the Humanities (DCH),
        Albertus-Magnus-Platz, 50923 Köln, hereinafter referred to as CLARIN Centre.
        The mission of CLARIN is to provide as wide access as possible to language
        research tools and materials around Europe [hosted in different CLARIN centres]. To achieve this
        goal, we set out some ground rules in this document [so that the CLARIN centres can legally distribute the tools
        and materials]. By accessing or using, and in consideration of the Services provided to you, you agree to abide by
        Terms below, which can be updated or modified according to article 9.
      </p>

      <h2 class="mat-h2">Terms of Use</h2>
      <ol>
        <li>
          <h3 class="mat-h3">Governing Terms</h3>
          <p>
          The access to and use of CLARIN services are governed by this Agreement and by its
          terms and conditions,
          which are hereby incorporated into this Agreement. The User’s attention is drawn to
          the provisions limiting access to certain
          specific classes of resources. Any use of the website by means of the User Identity
          granted by the local identity
          provider also signifies User’s acceptance of the terms and User’s agreement to be
          bound thereby.
          </p>
        </li>
        <li>
          <h3 class="mat-h3">Definitions</h3>
          <p>
          All terms in this Agreement, unless specifically defined herein, will have the
          meanings attributed to them
          in the Agreement.
          The following terms shall have the following meaning: "CLARIN" means CLARIN ERIC and
          national CLARIN service
          providers or centres. "Authorized Use" means use by a User who is accessing the
          website via the identity provided by
          national identity organizations. "Non-Commercial Use" refers to any use that does
          not generate income or is not used
          for promoting the generation of income. "User Identity" refers to the identity
          granted by a local identity provider [or
          CLARIN]. "CLARIN Services" refers to all tools and materials hosted in different
          CLARIN centres.
          </p>
        </li>
        <li>
          <h3 class="mat-h3">Access to CLARIN</h3>
          <p>
            The CLARIN centre hereby grants the User a limited non-exclusive non-transferable
            license to access and use
            the CLARIN resources it hosts under the terms of this Agreement and via the chosen
            User identity. Access to certain Features and
            databases may be restricted by CLARIN. User will be responsible for all access to
            CLARIN by means of the chosen User
            Identity whether or not the User has knowledge of such access and use. The CLARIN
            centre reserves the right to cancel
            any User Identity without notice. If a User suspects that somebody may misuse an
            identity, CLARIN should be notified
            immediately. </p>
          <p>
            User understands and acknowledges that the User Identity is for his or her use
            only and that the User
            is prohibited from permitting any third party from accessing CLARIN Services by
            means of the User Identity. Content
            Categories CLARIN offers content in three different categories:
          </p>

          <p>Public content (PUB) User understands and acknowledges that depending on the
            content the access may be
            limited based on this categorization and the User Identity. Also, CLARIN may require
            additional licensing or usage terms
            for Academic and Restricted Content and there may be steps like submitting more info
            for this purpose.
          </p>
          <p>
            User agrees to follow the categorization. Subcategories The offered content may
            also belong to a
            certain sub-category:
          </p>
        </li>
        <li>
          <h3 class="mat-h3"> Research Ethics </h3>
          <p>
            The User agrees to follow the best practices regarding research ethics.
            This includes treating colleagues, stakeholders, customers, suppliers and the public respectfully and
            professionally, taking into account confidentiality issues when appropriate, respecting cultural
            differences and having an open and explicit relationship with government, the public, the private sector
            and other founders.
            In addition, the User agrees to follow best academic practices while adding citations regarding the
            Content.
          </p>

        </li>
        <li>
          <h3 class="mat-h3"> Access to Service and Liability</h3>
          <p>
            The CLARIN centre disclaims all responsibility and liability for the availability, timeliness, security or
            reliability of the services, software or other content provided through the site. Similarly, the original
            owner or source of the content disclaims all responsibility and liability of the availability, timeliness,
            security or reliability of the Content.
            The CLARIN centre reserves the right to modify, suspend, or discontinue the services or access to the
            services without any notice at any time and without any liability to you.
          </p>

        </li>
        <li>
          <h3 class="mat-h3"> Governing Law and Entire Agreement</h3>
          <p>
            These Terms are governed by the laws of the Amtsgericht Köln, Luxemburger Straße 101, 50939 Köln without
            regard to the rules of conflict of law that may cause the laws of another jurisdiction to apply. User
            agrees to the sole and exclusive jurisdiction and venue of the Amtsgericht Köln, Luxemburger Straße 101,
            50939 Köln in the event of any dispute of any kind arising from or relating to the Site, or User’s use or
            review of it.
          </p>
          <p>
            However, the CLARIN centre has the right to use the laws of another jurisdiction to get injunctive measures
            or relieves against the misuse of the service.The Terms constitute the entire agreement between the parties
            with respect to the subject matter hereof and supersedes and replaces all prior or contemporaneous
            understandings or agreements, written or oral, regarding such subject matter. If for any reason a court of
            competent jurisdiction finds any provision or portion of these Terms to be unenforceable, the remainder of
            the Terms will continue in full force and effect.
          </p>
        </li>
        <li>
          <h3 class="mat-h3"> Data Protection and Privacy</h3>
          <p>
            User agrees with and agrees to follow the Privacy Notice set out in the separate agreement <a [routerLink]="['/docs/privacy-policy']">privacy
            policy</a>.
          </p>
        </li>
        <li>
          <h3 class="mat-h3"> Usage Statistics and Automated Querying</h3>

          <p>
            CLARIN strives to maintain the integrity of usage statistics as a measure of readership and other use of
            the CLARIN sites by authors and researchers. It is a violation of CLARIN policy for a party to directly or
            indirectly use CLARIN Services with a view to affection downloads and other usage statistics, or to
            encourage others to do so. As part of its general right to reuse or terminate service and remove or edit
            site content, the CLARIN centre reserves the right in its sole discretion to limit access, remove content,
            and adjust usage statistics to respond to any activity that appears likely to have such an effect.
          </p>
        </li>
        <li>
          <h3 class="mat-h3"> Termination</h3>
          <p>If User violates the letter of spirit of this agreement, or otherwise creates risk or possible legal
            exposure for CLARIN services, the CLARIN centre can stop providing all or part of the service. The CLARIN
            centre will notify User the next time he or she attempts to access the service.If these Terms of Service
            are modified for legal, administrative or any other reasons, the CLARIN Centre shall notify the users about
            these amendments by publishing the relevant information on the Centre’s website without unreasonable
            delay.If the User continues to use the services after being properly notified about the amendment of the
            Terms of Service, this implies his consent to the new Terms of Service.</p>
        </li>
      </ol>
      </section>
  `,
  styles: []
})
export class TermsOfUseComponent {

}
