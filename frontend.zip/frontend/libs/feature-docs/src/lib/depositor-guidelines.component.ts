import { Component } from '@angular/core';
import { faInfoCircle } from '@fortawesome/free-solid-svg-icons';

@Component({
  template: `
  <section>
  <h1 class="mat-h1">LAC Depositor Guidelines</h1>

  <p>
      These guidelines are intended to assist you in becoming a LAC
      depositor and provide you with the information you need to prepare
      your data for submission. If these guidelines and the linked
      documents do not answer all the questions you have or otherwise do
      not meet your needs, please contact the
      <a href="mailto:lac-helpdesk@uni-koeln.de" title="LAC-Helpdesk">LAC-Helpdesk</a>.
  </p>

  <h2 class="mat-h2">Becoming a depositor</h2>

  <p>
      A depositor is a LAC user with the rights to deposit data into one
      or more collections. If you want to deposit into an existing
      collection, we need the collection owner to notify us, so that we
      can grant you depositor rights. If you want to start a new
      collection, please contact us so that we can set up the collection
      and add the required information to its metadata.
  </p>

  <p>
      As a depositor, you need to be a holder of rights to the data – or
      the only holder of rights to the – and/or you need to be entitled to
      act with the permission of other parties that hold rights. To become
      a depositor you will also have to sign the LAC
      <a [routerLink]="['/docs/depositor-agreement']">Depositor Agreement</a> (pdf).
  </p>

  <p>
      If you want to become a depositor, please contact the
      <a href="&#109;&#97;&#x69;&#x6c;&#x74;&#111;&#58;&#108;&#97;&#99;&#x2d;&#x6d;&#x61;&#110;&#x61;&#103;&#101;&#114;&#x40;&#x75;&#x6e;&#x69;&#45;&#107;&#111;&#x65;&#x6c;&#x6e;&#46;&#100;&#101;">&#x4c;&#x41;&#67;
          &#x6d;&#x61;&#x6e;&#97;&#103;&#x65;&#114; </a>, and provide us with information about the data (data types,
      volume of data, legal situation of the data), so that we can grant
      depositor rights to your account.
  </p>

  <h2 class="mat-h2">Collections, bundles, and files</h2>

  <p>
      The LAC consist of three types of units: collection, bundles, and
      files. Collections contain bundles and bundles contain files. A file
      is always part of a bundle and a bundle is always part of a
      collection. Deposits consist of one or more bundles and need to be
      submitted to one particular collection.
  </p>

  <p>
      Collection are sets of bundles with a shared origin and/or topic.
      The prototypical collection consists of data from one research
      project or research team and have one consistent object language.
      Data from unrelated research projects, even if they share a single
      object language, should always be archived in different collections.
      A project that gathers data from more than one language should
      consider archiving the data sets in individual collections for each
      object language. However, related consecutive research projects may
      submit data to the same collection. If you are unsure whether your
      data would be better archived in an existing collection or in a new
      one or whether as one single collection or as two or more separate
      collections, please contact the
      <a href="&#x6d;&#x61;&#105;&#108;&#116;&#111;&#x3a;&#108;&#97;&#99;&#x2d;&#104;&#101;&#x6c;&#112;&#100;&#101;&#115;&#x6b;&#64;&#117;&#110;&#x69;&#45;&#107;&#x6f;&#101;&#108;&#110;&#46;&#100;&#x65;">&#x4c;&#x41;&#67;
          &#x68;&#101;&#108;&#112;&#100;&#101;&#x73;&#x6b; </a>.
  </p>

  <p>
      Bundles consist of a metadata file and any number of data files, in
      particular audio or video media files and accompanying annotations.
      Ideally, a bundle represents a single recorded event or any other
      salient unit of recording, documentation, or analysis. In
      particular, we recommend to keep bundles simple in structure. A
      single annotation file and the media files linked to this file plus
      supporting material (such as other annotation formats or pictures
      documenting the tasks and setup) are a prototypical bundle. Please
      avoid bundles with more one set of annotation file with its
      associated media files. If your bundle contains more than one
      annotation file of the same type, chances are high that the data
      would be better archived in two or more bundles.
  </p>

  <p>
      Files are the most basic entities the archive will handle. The LAC
      accepts a list of file types and file formats. The list of
      acceptable file formats can we found
      <a [routerLink]="['/docs/format-whitelist']">here</a>.
  </p>

  <p>
      A more detailed description of acceptable file types and best
      practices for preparing your data can be found in the
      <a [routerLink]="['/docs/submission-guidelines']">submission guidelines</a>.
  </p>

  <h2 class="mat-h2">Depositing</h2>

  <p>
      To prepare your data for submission, please follow the information
      in the <a [routerLink]="['/docs/submission-guidelines']">submission guidelines</a>.
      The LAC has currently no deposit inteface for users. Please contact
      us, so we can arrange the transfer of your submission ready data to
      us. After a compliance and consistency check, we will put your data
      into the LAC repository.
  </p>

  <p>
    <fa-icon [icon]="faInfo" [size]="'2x'"></fa-icon>
    If you have any remaining questions, please contact the
      <a href="mailto:lac-helpdesk@uni-koeln.de">LAC helpdesk</a>. We are
      also always happy to hear back from you with any suggestions or
      feedback which helps us to improve our submission guidelines.
  </p>
  </section>
  `
})
export class DepositorGuidelinesComponent {

  faInfo = faInfoCircle;

}
