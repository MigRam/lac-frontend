import { Component } from '@angular/core';

@Component({
  template: `
  <section>
  <h1 class="mat-h1">File Format Whitelist</h1>

  <p>
    <strong>Version: 2.0</strong>
    <strong>Date: 2018&#8211;04&#8211;16</strong>

    This list documents the file formats that are approved for
    submission and archiving at the Language Archvie Cologne. For a more
    detailed and descriptions of best practices regarding file formats
    see the
    <a [routerLink]="['/docs/submission-guidelines']">LAC Submission Guidelines</a>.
    For each data type, the acceptable file formats are given in the
    order of preference from the preference – from preferred to
    acceptable. However, all listed formats are equally accepted.
  </p>

  <h2 class="mat-h2">Metadata Files</h2>
  <div>
    <ul>
      <li>
        <strong>BLAM CMDI</strong>
        <a href="https://catalog.clarin.eu/ds/ComponentRegistry/?itemId=clarin.eu%253Acr1%253Ap_1475136016193&amp;registrySpace=public"
           target="_blank">(BLAM-bundle-repository-v0.14)</a>
      </li>
    </ul>
  </div>

  <h2 class="mat-h2">Audio files</h2>
  <div>
    <ul>
      <li>
        <strong>WAV</strong> with Linear Pulse Code Modulation (LPCM)
        audio (preferred sampling rate 48 kHz and bit depth 16 bit)
      </li>
    </ul>
  </div>

  <h2 class="mat-h2">Video Files</h2>
  <div>
    <ul>
      <li>
        <strong>MP4</strong> Video codec h.264 (preferred profile: main,
        level: 4.0, 1080p, 30fps), Audio encoding AAC (LC) (preferred
        sampling rate 48 kHz and bit rate 128&#8211;384 kbps).
      </li>
      <li>
        <strong>MOV</strong> Video codec h.264 (preferred profile: main,
        level: 4.0, 1080p, 30fps), Audio encoding LPCM (preferred
        sampling rate 48 kHz and bit depth 16 bit).
      </li>
    </ul>
  </div>

  <h2 class="mat-h2">Annotations</h2>
  <div>
    <ul>
      <li>
        <strong>
          <a href="http://www.mpi.nl/corpus/html/elan/index.html" target="_blank">ELAN annotations</a>
        </strong>
      </li>
      <li>
        <strong>
          <a href="http://www.fon.hum.uva.nl/praat/manual/TextGrid_file_formats.html" target="_blank">Praat
            TextGrid
          </a>
        </strong>
      </li>
      <li>
        <strong>
          <a href="http://exmaralda.org/en/partitur-editor-en/" target="_blank">Exmaralda trasncriptions</a>
        </strong>
      </li>
      <li>
        <strong>
          <a href="http://www.tei-c.org/Guidelines/P5/" target="_blank">TEI</a>
        </strong>
        (in particular
        <a href="https://www.iso.org/standard/37338.html" target="_blank">ISO 24624:2016</a>)
      </li>
      <li>
        <strong>
          <a href="https://software.sil.org/fieldworks/wp-content/uploads/sites/38/2016/10/FieldWorks-XML-model.pdf"
             target="_blank">FLeX XML</a>
        </strong>
      </li>
      <li>
        <strong>
          <a href="https://software.sil.org/toolbox/" target="_blank">Toolbox Files</a>
        </strong>
      </li>
    </ul>
  </div>

  <h2 class="mat-h2">Written resources</h2>
  <ul>
    <li><strong>Text files</strong> (plain UTF&#8211;8 encoded)</li>
    <li>
      <strong>
        <a href="https://en.wikipedia.org/wiki/PDF/A" target="_blank">PDF/A</a>
      </strong>
    </li>
    <li><strong>XHTML</strong></li>
  </ul>

  <h2 class="mat-h2">Still Images</h2>
  <ul>
    <li><strong>TIFF</strong></li>
    <li><strong>JPEG2000</strong></li>
    <li><strong>PNG</strong></li>
    <li><strong>JPEG</strong></li>
  </ul>

  <h2 class="mat-h2">Additional metadata</h2>
  <ul>
    <li>
      <strong>
        <a href="https://www.clarin.eu/content/component-metadata" target="_blank">CMDI Metadata</a>
      </strong>
    </li>
    <li>other XML Metadata formats</li>
    <li>
      CSV encoded metadata (preferably with
      <a href="https://www.w3.org/TR/2015/REC-tabular-metadata-20151217/" target="_blank">W3C Metadata Vocabulary
        for Tabular Data</a>
      annotations)
    </li>
  </ul>
  </section>
  `
})
export class FormatWhitelistComponent {


}
