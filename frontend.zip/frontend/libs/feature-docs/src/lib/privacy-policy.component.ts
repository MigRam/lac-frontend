import { Component } from '@angular/core';

@Component({
  template: `
  <section>
  <h1 class="mat-h1">CLARIN Privacy Policy</h1>

  <p>
      Ein Mustervertrag für die Datenschutzbestimmungen wurde unten
      entworfen. Abhängig vom Inhalt der Verarbeitungsdienste und der
      nationalen Gesetzeslage des Inhaltsanbieters, muss der Mustervertrag
      an einigen Stellen angepasst werden.
  </p>

  <p>
      Diese Datenschutzbestimmungen beziehen sich auf/gelten für Seite und
      Services des Repositories <a [routerLink]="'/'">lac.uni-koeln.de</a> (beide
      zusammen „CLARIN-Service“), die darin bereitgestellt werden,
      betrieben von Data Center for The Humanities (DCH),
      Albertus-Magnus-Platz, 50923 Köln als CLARIN-Service Provider
      (später „CLARIN-Service Provider“). Diese Datenschutzbestimmungen
      beschreiben die personenbezogenen Daten, die wir von Ihnen bezüglich
      des CLARIN-Services erheben und wie wir diese Informationen nutzen
      werden.
  </p>

  <strong>
      Mit der Nutzung des CLARIN-Services, erklären Sie, die Bedingungen
      dieser CLARIN-Datenschutzbestimmungen zu akzeptieren.
  </strong>

  <p>
      Diese Datenschutzbestimmungen gelten nicht notwendig für Praktiken
      anderer CLARIN-Service Provider. Diese CLARIN-Service Provider
      können ihre eigenen Datenschutzbestimmungen haben, die auf ihren
      CLARIN-Seiten eingesehen werden können (Links). Die anderen
      CLARIN-Service Provider können verlangen, dass Sie deren
      Datenschutzbestimmungen akzeptieren, wenn Sie deren Services nutzen.
  </p>

  <p>
      Allerdings hat sich mit dem Beitritt zu CLARIN jeder CLARIN-Service
      Provider uneingeschränkt auf die aktuell gültige Gesetzeslage zum
      Datenschutzrecht verpflichtet, hinsichtlich jeglicher Art der
      Bearbeitung und Weitergabe personenbezogener Daten, der
      Verpflichtung zu Vertraulichkeit und Geheimhaltung und ebenso zur
      Bereitstellung eines ausreichenden Datensicherheitslevels für die
      Services.
  </p>

  <h2 class="mat-h2">Erhebung Ihrer personenbezogenen Daten</h2>
  <p>
      Diese Datenschutzbestimmung gilt für die Erhebung Ihrer
      personenbezogenen Daten durch den CLARIN-Service Provider.
      Personenbezogene Daten sind solche Informationen, die dazu genutzt
      werden können, ein Individuum zu identifizieren, einschließlich,
      aber nicht beschränkt auf Namen, private Anschrift und
      E-Mailadressen.
  </p>

  <h2 class="mat-h2">Anmeldedaten/Registrierungsformalitäten</h2>
  <p>
      Die Registrierung kann erforderlich sein, um den CLARIN-Service zu
      nutzen. In diesem Fall, können Nutzer, die einen Service anfragen,
      verpflichtet sein, bei der Registrierung bestimmte persönliche
      Angaben zu machen, wie z.B. Name, E-Mailadresse, Benutzername und
      Passwort.
  </p>

  <h2 class="mat-h2">
      Daten, die während der Nutzung des CLARIN-Services erhoben werden
  </h2>
  <p>
      Wenn Sie die CLARIN-Services besuchen, können folgende Angaben
      automatisch erhoben werden:
  </p>
  <ul class="list-unstyled">
      <li>Name der Domain, von der Sie das Internet betreten,</li>
      <li>IP-Adresse des Nutzers,</li>
      <li>Datum und Uhrzeit, zu der Sie auf unsere Seite zugreifen,</li>
      <li>
          Seiten, die Sie innerhalb der CLARIN-Infrastruktur besuchen.
      </li>
  </ul>

  <p>
      Diese Informationen werden genutzt zu Zwecken wie der Beurteilung,
      welche Informationen von größtem Interesse sind für die Nutzer und
      zu Systemverbesserungen. Außerdem speichern wir Informationen, die
      Sie uns während Ihrer Nutzung des CLARIN-Services bereitstellen.
      Diese Informationen können z.B. persönliche Korrespondenz wie
      E-Mails oder Briefe umfassen.
  </p>

  <h2 class="mat-h2">Cookies oder andere Tracking Technologien</h2>
  <p>
      Der CLARIN-Services verwendet Cookies, um den
      Protokollierungsprozess mancher Bereiche der Seite zu
      automatisieren. Ihr Webbrowser kann so eingestellt werden, dass sie
      kontrollieren können, ob Sie Cookies akzeptieren, ablehnen oder
      jedes Mal benachrichtigt werden, wenn Ihnen ein Cookie gesendet
      wird.
  </p>

  <h2 class="mat-h2">Nutzung der personenbezogenen Daten</h2>
  <p>
      Wir nutzen personenbezogene Daten, um Ihnen die CLARIN-Services, die
      Sie angefragt haben, bereitzustellen und zu Zwecken der
      Administration. Personenbezogene Daten werden vom CLARIN-Service
      Provider mindestens für alle folgenden Fälle benutzt:
  </p>

  <ul>
      <li>
          um Sie zu identifizieren, um Ihnen das CLARIN-Material, das Sie
          angefragt haben, bereitzustellen,
      </li>
      <li>
          um Ihre Fragen zu beantworten und für andere Kommunikation mit
          Ihnen,
      </li>
      <li>
          für die Auditierung und Forschungsanalyse, um den CLARIN-Service
          zu erhalten, zu schützen und zu verbessern und um die
          Eigentumsrechte des CLARIN-Materials und Services zu schützen, und
      </li>
      <li>
          um den technischen Betrieb des CLARIN-Services und Netzwerks
          sicherzustellen.
      </li>
  </ul>

  <h2 class="mat-h2">Weitergabe personenbezogener Daten</h2>
  <p>
      Über die gesetzlich zulässige Weitergabe oder über diese
      Datenschutzbestimmungen hinaus, werden personenbezogene Daten nicht
      an andere Organisationen oder Personen weitergegeben. Wir geben
      (wörtl: verkaufen oder vermieten) Ihre personenbezogenen Daten nicht
      an Dritte zu Marketingzwecken weiter. Wir müssen Ihre Angaben mit
      unseren Service Providern für Datenverarbeitungszwecke und zur
      Speicherung in unserem Auftrag teilen/austauschen. Wir verlangen,
      dass diese Parteien in die Verarbeitung Ihrer Daten basierend auf
      unseren Instruktionen und in Übereinstimmung mit diesen
      Datenschutzbestimmungen und der gültigen Gesetzgebung zum Schutz
      personenbezogener Daten einwilligen. Außerdem müssen wir Ihre
      Angaben mit den anderen CLARIN-Service Providern teilen/austauschen,
      um Ihnen den Zugang zum CLARIN-Material anderer CLARIN-Service
      Provider bereitstellen zu können. Wir teilen/tauschen nur die
      folgenden beschränkten/geringen Angaben mit anderen CLARIN-Service
      Providern aus:
  </p>

  <ul>
      <li>
          notwendige Identifikationsangaben, z.B. Ihren Namen, Nutzer-ID und
          Nationalität und
      </li>
      <li>Limit Ihrer Zugangsrechte zum CLARIN-Service.</li>
  </ul>

  <h2 class="mat-h2">Datenspeicherung</h2>
  <p>
      Wir werden Ihre personenbezogenen Daten nicht länger als nötig
      behalten, um die Zwecke zu erfüllen, für die sie gesammelt wurden
      oder es aufgrund anwendbarer Gesetze und Regelungen erforderlich
      ist.
  </p>

  <h2 class="mat-h2">Zugang zu und Berichtigung der personenbezogenen Daten</h2>
  <p>
      Sie haben das Recht, eine Kopie der Informationen, die wir von Ihnen
      vorhalten, zu verlangen und jegliche Ungenauigkeiten in Ihren
      Angaben berichtigen zu lassen.
  </p>

  <h2 class="mat-h2">Aktualisierung Ihrer Angaben</h2>
  <p>
      Wenn sich Ihre Angaben ändern, teilen Sie uns dies bitte per E-Mail
      mit:
      <a href="mailto:lac-manager@uni-koeln.de">lac-manager@uni-koeln.de</a>.
  </p>

  <h2 class="mat-h2">Sicherheit</h2>
  <p>
      Wir werden angemessene und geeignete Schritte unternehmen, um Ihre
      personenbezogenen Angaben, die Sie mit uns teilen, vor
      unautorisierten Zugriffen und vor einer Weitergabe zu schützen.
      Diese Maßnahmen enthalten z.B. das Folgende:
  </p>

  <ul>
      <li>
          nur autorisierte Mitarbeiter haben Zugang zu den Daten, die für
          die Verarbeitung und Wartung der Datenbank, die Informationslisten
          speichert, erhoben wurden,
      </li>
      <li>
          interne Überprüfungen unserer Datensammlung sowie Speicherungs-
          und Verarbeitungspraktiken.
      </li>
  </ul>

  Die personenbezogenen Daten werden gespeichert von
  <a href="mailto:lac-manager@uni-koeln.de">lac-manager@uni-koeln.de</a>.

  <h2 class="mat-h2">Links zu anderen Webseiten</h2>
  <p>
      Der CLARIN-Service kann Links zu anderen Webseiten enthalten. Bitte
      beachten Sie, dass, wenn Sie einen dieser Links anklicken, Sie auf
      eine andere Webseite gelangen können, für die der CLARIN-Service
      Provider nicht verantwortlich ist und über die er keine Kontrolle
      hat. Der CLARIN-Service Provider teilt keine personenbezogenen Daten
      mit diesen Seiten, außer wenn etwas anderes vereinbart wurde.
  </p>

  <h2 class="mat-h2">Änderungen dieser Datenschutzbestimmungen</h2>
  <p>
      Wir behalten uns das Recht vor, unsere Datenschutzbestimmungen
      abzuändern; und solche neuen Bestimmungen werden auf unsere Webseite
      gestellt, um Sie aktuell zu informieren wie wir unsere Daten
      erheben, nutzen, verwalten, weitergeben/veröffentlichen und die
      personenbezogenen Daten schützen. Solche Änderungen werden an dieser
      Stelle auf unsere Webseite gestellt und der Tag des Wirksamwerdens
      der Bestimmungen wird entsprechend aktualisiert. Sie sind dafür
      verantwortlich, diese Datenschutzbestimmungen regelmäßig zu
      überprüfen. Die weitere Nutzung dieser Seite gilt als Ihre
      Zustimmung zu solchen Änderungen.
  </p>

  <h2 class="mat-h2">Kontaktinformationen</h2>
  <p>
      Weitere Fragen zu diesen Datenschutzbestimmungen richten Sie an:
      <a href="mailto:lac-manager@uni-koeln.de">lac-manager@uni-koeln.de</a>
  </p>

  <h2 class="mat-h2">Anzuwendendes Recht</h2>
  <p>
      Diese Datenschutzbestimmung und die Datenschutzpraktiken des
      CLARIN-Service Providers unterliegen ausschließlich den Gesetzen vom
      Amtsgericht Köln, Luxemburger Straße 101, 50939 Köln. Der
      CLARIN-Service Provider erhebt keinen Anspruch darauf, dass diese
      Datenschutzbestimmungen und solche Praktiken den Gesetzen anderer
      Länder entsprechen. Besucher, die den CLARIN-Service außerhalb
      Europas nutzen, tun dies aus eigener Initiative und sind
      verantwortlich für die Einhaltung der örtlichen Gesetze, wenn und
      soweit die örtlichen Gesetze anwendbar sind. Wenn sie außerhalb
      Europas leben, willigen Sie mit der Nutzung des CLARIN-Service in
      die Übertragung und Nutzung Ihrer Informationen außerhalb Ihres
      Landes ein.
  </p>
  <strong>Tag des Wirksamwerdens der Datenschutzbestimmungen: 24.04.2018</strong>
  </section>
  `
})
export class PrivacyPolicyComponent {

}
