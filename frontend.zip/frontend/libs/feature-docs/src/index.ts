export { FeatureDocsModule } from './lib/feature-docs.module';
