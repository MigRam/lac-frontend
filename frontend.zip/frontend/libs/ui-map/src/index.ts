export { UiMapModule } from './lib/ui-map.module';
