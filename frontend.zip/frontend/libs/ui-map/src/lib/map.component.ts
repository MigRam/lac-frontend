import { AfterViewInit, ChangeDetectionStrategy, Component, ComponentFactoryResolver, Injector, Input } from "@angular/core";
import { A5QueryApiService } from '@lac/apis';
import * as L from "leaflet";
import "leaflet.markercluster";
import { PopupComponent } from './popup.component';

const DEFAULT_TILE_LAYER = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';

const DEFAULT_TILE_LAYER_ATTRIBUTION = '&copy; <a href="http://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a>';

const MAP_ICONS = L.icon({
  iconUrl: "https://cdn.rawgit.com/pointhi/leaflet-color-markers/master/img/marker-icon-black.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.0.1/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [13, 41]
});

const zoomFeature = (map) => {
  const zoomButton = L.Control.extend({
    options: { position: "topleft" },
    onAdd: function () {
      const container = L.DomUtil.create("button", "leaflet-bar leaflet-button-control");
      container.setAttribute('title', 'Click to fit world map');
      container.style.cursor = "pointer";
      container.insertAdjacentHTML("beforeend", '<i class="material-icons">map</i>');
      container.onclick = (e) => {
        e.preventDefault();
        const mapZoomValue = map.getZoom();
        if (mapZoomValue !== 1) {
          map.fitWorld().setView([0, 0], 1);
        }
      };
      return container;
    }
  });
  map.addControl(new zoomButton());
}

@Component({
  selector: "lac-map",
  template: `
    <div [id]="mapId"></div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MapComponent implements AfterViewInit {

  @Input() mapId;

  @Input()
  set mapData(data) {
    if (data) {
      this.renderMap(data)
    }
  };

  private map;

  markerClusterGroup = L.markerClusterGroup({
    spiderfyOnMaxZoom: false,
    showCoverageOnHover: false,
    removeOutsideVisibleBounds: false,
    maxClusterRadius: 20
  })
    .on("clusterclick", (e: any) => e.layer.spiderfy());

  constructor(
    private querySvc: A5QueryApiService,
    private resolver: ComponentFactoryResolver,
    private injector: Injector
  ) {

  }

  ngAfterViewInit(): void {

    if ( this.map !== undefined) { 
      this.map.remove(); 
    }
    
    this.initMap();
  }


  initMap() {
    this.map = new L.Map(this.mapId, {
      layers: [L.tileLayer(DEFAULT_TILE_LAYER, { maxZoom: 18, attribution: DEFAULT_TILE_LAYER_ATTRIBUTION })],
      zoom: 1,
      center: L.latLng([0, 0])
    });

    this.map.addLayer(this.markerClusterGroup);
    this.map.invalidateSize();
    // zoomFeature(this.map);
  }

  renderMap(data) {
    this.clearMarkerCluster();
    this.generateMarkerCluster(data);
    this.refreshZoom(this.map);
  }

  generateMarkerCluster(geodata) {

    geodata.forEach(element => {

      if (element?.GeoLocation) {
        const factory = this.resolver.resolveComponentFactory(PopupComponent);
        const popupComponent = factory.create(this.injector);

        const geolocation = element.GeoLocation[0];
        const lat = geolocation.split(",")[0];
        const lng = geolocation.split(",")[1];
        const marker = L.marker([lat, lng], { icon: MAP_ICONS });

        this.markerClusterGroup.addLayer(marker);

        marker.on('click', <LeafletMouseEvent>(e: any) => {
          this.querySvc
            .filterById(element.id)
            .subscribe(response => {
              for (const i of response.dataset) {
                popupComponent.instance.data = i;
                popupComponent.changeDetectorRef.detectChanges();
              }
            });

          this.map.setView(e.latlng, this.map.getZoom());

        });

        marker.bindPopup(popupComponent.location.nativeElement, {
          minWidth: 400,
          maxWidth: 700,
          autoPan: true,
          maxHeight: 500,
          keepInView: true
        });

        marker.addTo(this.markerClusterGroup);
      }
    })
  }

  generateSingleMarker(geodata) {
    const lat = geodata.split(",")[0];
    const lng = geodata.split(",")[1];
    L.marker([lat, lng], { icon: MAP_ICONS });
    this.map._handlers.forEach(function(handler) {
      handler.disable();
    });

    this.map.setView([lat, lng], 4);
  }


  clearMarkerCluster() {
    this.markerClusterGroup.clearLayers();
  }

  refreshZoom(map) {
    if (map !== undefined) {
      const actualZoom = map.getZoom();
      if (actualZoom > 1) {
        return map.setView([0, 0], 1, { animate: true });
      }
    }
  }

}
