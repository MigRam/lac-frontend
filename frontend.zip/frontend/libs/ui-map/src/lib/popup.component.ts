import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'lac-popup',
  template: `
     <div class="mat-typography">
        <mat-card-header>
          <mat-card-title>
            <mat-icon [inline]="true">link</mat-icon>
            <a class="mat-h4" title="View details of {{ data?.title }}" (click)="navigate(data)"> {{ data?.title }} </a>
          </mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <p class="mat-small">{{ data?.shortDescription }}</p>
          <mat-chip-list>
            <mat-chip *ngFor="let language of data?.languages | slice:0:3" color="isLanguage" selected>
              <small [innerHTML]="language"></small>
            </mat-chip>
            <mat-chip *ngFor="let keyword of data?.keywords | slice:0:3" color="isKeyword" selected>
              <small [innerHTML]="keyword"></small>
            </mat-chip>
          </mat-chip-list>
        </mat-card-content>
      </div>
    `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PopupComponent {

  @Input() data;

  constructor(private router: Router) { }

  navigate(item) {
    this.router.navigateByUrl(`/${item.routePrefix}/${item.routeId}`);
  }

}
