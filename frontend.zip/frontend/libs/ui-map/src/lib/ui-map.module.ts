import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MapComponent } from './map.component';
import { PopupComponent } from './popup.component';
import { UiMaterialDesignModule } from '@lac/ui-material-design';

@NgModule({
  imports: [
    CommonModule,
    UiMaterialDesignModule
  ],
  declarations: [MapComponent, PopupComponent ],
  exports: [MapComponent],
  entryComponents: [
    MapComponent,
    PopupComponent
  ]
})
export class UiMapModule {}
