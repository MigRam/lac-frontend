import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'lac-about',
  template: `
  <h2 mat-dialog-title>
    The Language Archive Cologne (LAC)
  </h2>
  <mat-dialog-content class="mat-typography">
    The archive is a research data repository for linguistics and all humanities
    disciplines that work with audiovisual data.
  </mat-dialog-content>
  `,
  styles: [``],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AboutComponent {

}
