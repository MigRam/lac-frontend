import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { faBook, faCloudUploadAlt, faHome, faInfoCircle, faSignInAlt, faSignOutAlt, faUserCheck, faUserCog } from '@fortawesome/free-solid-svg-icons';
import { AuthService } from '@lac/apis';
import { LOGO_CLARIN, LOGO_DCH, LOGO_LAC, LOGO_RRZK, LOGO_UZK } from '@lac/ui-assets';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { AboutComponent } from '../about.component';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'lac-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit, OnDestroy {

  title = "Language Archive Cologne";
   
  logo = LOGO_LAC.default;
  faSignIn = faSignInAlt;
  faSignOut = faSignOutAlt;
  faHome = faHome;
  faBook = faBook;
  faInfo = faInfoCircle;
  faDeposit = faCloudUploadAlt;
  faAdmin = faUserCog;
  faAccount = faUserCheck;

  @Input() links: string | Array<object>;
  @Input() authLinks: string | Array<object>;

  date: number = Date.now();

  supporters = [
    {
      name: "Universität zu Köln - Institut für Linguistik - Allgemeine Sprachwissenschaft",
      link: "http://ifl.phil-fak.uni-koeln.de",
      display: "_blank",
      image: `${LOGO_UZK.default}`,
      size: "image-is-small"
    },
    {
      name: "Data Center for the Humanities (DCH)",
      link: "http://dch.phil-fak.uni-koeln.de",
      display: "_blank",
      image: `${LOGO_DCH.default}`,
      size: "image-is-big"
    },
    {
      name: "RRZK: Regionales Rechenzentrum der Universität zu Köln",
      link: "https://rrzk.uni-koeln.de",
      display: "_blank",
      image: `${LOGO_RRZK.default}`,
      size: "image-is-small"
    },
    {
      name: "CLARIN - European Research Infrastructure for Language Resources and Technology",
      link: "https://www.clarin.eu",
      display: "_blank",
      image: `${LOGO_CLARIN.default}`,
      size: "image-is-small"
    },
    {
      name: "LAC - Language Archive Cologne",
      link: ".",
      display: "_self",
      image: `${LOGO_LAC.default}`,
      size: "image-is-small"
    }
  ];

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );

  constructor(
    private breakpointObserver: BreakpointObserver,
    private matDialog: MatDialog,
    public authSvc: AuthService
    ) {
    }
  
  ngOnInit() {
    
  }

  openDialog() {
    this.matDialog.open(AboutComponent)
  }

  ngOnDestroy() {
    
  }

}
