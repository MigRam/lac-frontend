import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router'; //
import { UiMaterialDesignModule } from '@lac/ui-material-design';
import { NavbarComponent } from './navbar/navbar.component';
import { AboutComponent } from './about.component';
import { ImpressumComponent } from './impressum.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { ApisModule } from '@lac/apis';

@NgModule({
  declarations: [ NavbarComponent, AboutComponent, ImpressumComponent ],
  imports: [
    CommonModule,
    UiMaterialDesignModule,
    RouterModule,
    FontAwesomeModule,
    ApisModule
  ],
  exports: [ NavbarComponent, ImpressumComponent ],
  entryComponents: [ AboutComponent ]
})
export class UiNavigationModule {


}
