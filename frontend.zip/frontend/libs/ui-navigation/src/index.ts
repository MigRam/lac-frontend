import { ImpressumComponent } from './lib/impressum.component';

export { UiNavigationModule } from './lib/ui-navigation.module';
export { ImpressumComponent } from './lib/impressum.component';