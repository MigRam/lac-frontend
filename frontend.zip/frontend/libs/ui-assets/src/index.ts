export { LOGO_ELAC } from './lib/ui-assets.module';
export { LOGO_LAC } from './lib/ui-assets.module';
export { LOGO_LAC2 } from './lib/ui-assets.module';
export { LOGO_UZK } from './lib/ui-assets.module';
export { LOGO_CCEH } from './lib/ui-assets.module';
export { LOGO_CLARIN } from './lib/ui-assets.module';
export { LOGO_DCH } from './lib/ui-assets.module';
export { LOGO_ORCID } from './lib/ui-assets.module';
export { LOGO_RRZK } from './lib/ui-assets.module';
export { SETUP_OAIS } from './lib/ui-assets.module';

export { UiAssetsModule } from './lib/ui-assets.module';
