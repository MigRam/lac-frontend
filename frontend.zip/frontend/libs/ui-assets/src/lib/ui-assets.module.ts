import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

declare function require(path: string);

export const LOGO_LAC = require('./images/logo-LAC.png');
export const LOGO_LAC2 = require('./images/logo-LAC-2.png');
export const LOGO_CCEH = require('./images/logo-CCeH.png');
export const LOGO_CLARIN = require('./images/logo-CLARIN.png');
export const LOGO_DCH = require('./images/logo-DCH.png');
export const LOGO_ORCID = require('./images/logo-ORCID.png');
export const LOGO_RRZK = require('./images/logo-RRZK.png');
export const LOGO_UZK = require('./images/logo-UZK.png');
export const SETUP_OAIS = require('./images/setup_OAIS.png');
export const INGEST = require('./images/ingest.png');
export const LOGO_ELAC = require('./images/logo-ELAC.png');
// export const KA3_VECTOR = require('./images/ka3-vector.svg');

@NgModule({
  imports: [CommonModule],
})
export class UiAssetsModule {}
